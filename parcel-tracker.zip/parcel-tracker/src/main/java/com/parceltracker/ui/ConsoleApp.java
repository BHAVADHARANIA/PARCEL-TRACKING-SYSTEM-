package com.parceltracker.ui;

import com.parceltracker.model.*;
import com.parceltracker.service.*;
import com.parceltracker.sim.DataSimulator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Text-based front end. */
public class ConsoleApp {
    private final ParcelService service;
    private final Scanner in = new Scanner(System.in);

    public ConsoleApp(ParcelService service) { this.service = service; }

    public static void main(String[] args) {
        ParcelService service = new ParcelService(new ParcelRepository());
        int n = DataSimulator.populate(service, 120, 42L);
        System.out.println("Loaded " + n + " simulated parcels.");
        new ConsoleApp(service).run();
    }

    private void run() {
        while (true) {
            System.out.println("""

                ===== PARCEL TRACKER =====
                1. Create parcel
                2. Track parcel (view history)
                3. Advance parcel to next stage
                4. Set specific status (tests validation)
                5. List parcels (first 20)
                6. Dashboard summary
                0. Exit""");
            System.out.print("Choose: ");
            if (!in.hasNextLine()) return;
            String c = in.nextLine().trim();
            try {
                switch (c) {
                    case "1" -> create();
                    case "2" -> track();
                    case "3" -> advance();
                    case "4" -> setStatus();
                    case "5" -> list();
                    case "6" -> summary();
                    case "0" -> { System.out.println("Bye!"); return; }
                    default -> System.out.println("Invalid option.");
                }
            } catch (InvalidTransitionException e) {
                System.out.println("REJECTED: " + e.getMessage());
            } catch (RuntimeException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private String ask(String q) { System.out.print(q + ": "); return in.nextLine().trim(); }

    private void create() {
        Parcel p = service.createParcel(ask("Sender"), ask("Recipient"), ask("Destination city"), ask("Origin city"));
        System.out.println("Created " + p);
    }

    private void track() {
        Parcel p = service.get(ask("Parcel ID (e.g. PKG1001)").toUpperCase());
        System.out.println(p);
        p.getHistory().forEach(e -> System.out.println("  " + e));
        System.out.println("  Next allowed: " + (p.getStatus().isTerminal() ? "none (final)" : p.getStatus().allowedNext()));
    }

    private void advance() {
        String id = ask("Parcel ID").toUpperCase();
        StatusEvent e = service.advanceToNext(id, ask("Current location"), ask("Note (optional)"));
        System.out.println("Updated: " + e);
    }

    private void setStatus() {
        String id = ask("Parcel ID").toUpperCase();
        for (ParcelStatus s : ParcelStatus.values()) System.out.println("  " + s.ordinal() + " = " + s);
        ParcelStatus target = ParcelStatus.values()[Integer.parseInt(ask("Target status number"))];
        System.out.println("Updated: " + service.update(id, target, ask("Location"), ask("Note (optional)")));
    }

    private void list() {
        List<Parcel> all = service.all();
        all.stream().limit(20).forEach(System.out::println);
        System.out.println("... showing 20 of " + all.size());
    }

    private void summary() {
        for (Map.Entry<ParcelStatus, Long> e : service.summary().entrySet())
            System.out.printf("%-18s %3d%n", e.getKey().label(), e.getValue());
        System.out.println("Total: " + service.all().size());
    }
}
