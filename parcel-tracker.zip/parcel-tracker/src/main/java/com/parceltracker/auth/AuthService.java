package com.parceltracker.auth;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Accounts (PBKDF2-hashed passwords) and in-memory sessions. */
public class AuthService {
    public enum Role { USER, ADMIN }
    public record User(String username, String name, Role role) { }
    private record Cred(User user, byte[] salt, byte[] hash) { }
    private record Sess(String username, long expires) { }

    private static final long TTL_MS = 8L * 3600 * 1000;
    private static final SecureRandom RNG = new SecureRandom();
    private static final byte[] DUMMY_SALT = new byte[16];
    private final Map<String, Cred> creds = new HashMap<>();
    private final Map<String, Sess> sessions = new ConcurrentHashMap<>();

    public void register(String username, String name, String password, Role role) {
        byte[] salt = new byte[16];
        RNG.nextBytes(salt);
        String key = username.trim().toLowerCase();
        creds.put(key, new Cred(new User(key, name, role), salt, hash(password, salt)));
    }

    public Optional<User> authenticate(String username, String password) {
        Cred c = creds.get(username == null ? "" : username.trim().toLowerCase());
        byte[] h = hash(password == null ? "" : password, c == null ? DUMMY_SALT : c.salt());
        return (c != null && MessageDigest.isEqual(h, c.hash())) ? Optional.of(c.user()) : Optional.empty();
    }

    public String login(User u) {
        byte[] b = new byte[32];
        RNG.nextBytes(b);
        String token = HexFormat.of().formatHex(b);
        sessions.put(token, new Sess(u.username(), System.currentTimeMillis() + TTL_MS));
        return token;
    }

    public Optional<User> userFor(String token) {
        if (token == null) return Optional.empty();
        Sess s = sessions.get(token);
        if (s == null) return Optional.empty();
        if (s.expires() < System.currentTimeMillis()) { sessions.remove(token); return Optional.empty(); }
        Cred c = creds.get(s.username());
        return c == null ? Optional.empty() : Optional.of(c.user());
    }

    public void logout(String token) { if (token != null) sessions.remove(token); }

    private static byte[] hash(String pw, byte[] salt) {
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(new PBEKeySpec(pw.toCharArray(), salt, 20000, 256)).getEncoded();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
}
