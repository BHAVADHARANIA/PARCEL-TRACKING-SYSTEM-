package com.parceltracker.model;

import java.util.EnumSet;
import java.util.Set;

/**
 * The 6 delivery stages and the ONLY legal transitions between them.
 * The transition table lives inside the enum so no other class can bypass it.
 */
public enum ParcelStatus {
    ORDER_PLACED("Order Placed"),
    PICKED_UP("Picked Up"),
    IN_TRANSIT("In Transit"),
    AT_LOCAL_FACILITY("At Local Facility"),
    OUT_FOR_DELIVERY("Out for Delivery"),
    DELIVERED("Delivered");

    private final String label;

    ParcelStatus(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    /** Legal next states from this state (empty set = terminal). */
    public Set<ParcelStatus> allowedNext() {
        return switch (this) {
            case ORDER_PLACED     -> EnumSet.of(PICKED_UP);
            case PICKED_UP        -> EnumSet.of(IN_TRANSIT);
            case IN_TRANSIT       -> EnumSet.of(AT_LOCAL_FACILITY);
            case AT_LOCAL_FACILITY -> EnumSet.of(OUT_FOR_DELIVERY);
            case OUT_FOR_DELIVERY -> EnumSet.of(DELIVERED);
            case DELIVERED        -> EnumSet.noneOf(ParcelStatus.class);
        };
    }

    public boolean canTransitionTo(ParcelStatus next) {
        return next != null && allowedNext().contains(next);
    }

    public boolean isTerminal() {
        return allowedNext().isEmpty();
    }

    /** The single next state in the happy path, or null when terminal. */
    public ParcelStatus next() {
        return isTerminal() ? null : allowedNext().iterator().next();
    }
}
