package com.parceltracker.model;

import java.time.LocalDateTime;
import java.util.Objects;

/** One immutable entry in a parcel's history. A record has final fields and no setters. */
public record StatusEvent(ParcelStatus status, LocalDateTime timestamp, String location, String note) {

    public StatusEvent {
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(timestamp, "timestamp");
        location = (location == null || location.isBlank()) ? "Unknown" : location.trim();
        note = (note == null) ? "" : note.trim();
    }

    @Override
    public String toString() {
        return String.format("%s | %-17s | %s%s", timestamp.truncatedTo(java.time.temporal.ChronoUnit.SECONDS).toString().replace('T', ' '),
                status.label(), location, note.isEmpty() ? "" : " | " + note);
    }
}
