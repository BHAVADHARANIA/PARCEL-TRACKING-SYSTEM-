package com.parceltracker.model;

import java.time.LocalDateTime;

/** Immutable audit entry (cancellation requests and decisions). */
public record ActivityEvent(LocalDateTime timestamp, String actor, String text) { }
