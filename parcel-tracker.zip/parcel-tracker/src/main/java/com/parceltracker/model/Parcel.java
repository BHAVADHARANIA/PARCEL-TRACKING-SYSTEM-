package com.parceltracker.model;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Parcel aggregate. Status changes go only through advanceTo (state machine);
 * cancellation goes only through request/confirm/reject (approval workflow).
 * Histories are append-only and exposed read-only.
 */
public final class Parcel {
    private final String id, owner, sender, recipient, destination;
    private final List<StatusEvent> history = new ArrayList<>();
    private final List<ActivityEvent> activity = new ArrayList<>();
    private CancellationState cancellation = CancellationState.NONE;
    private String cancelReason = "", decisionNote = "";
    private LocalDateTime cancelRequestedAt;

    public Parcel(String id, String sender, String recipient, String destination,
                  String origin, LocalDateTime createdAt) {
        this(id, "unassigned", sender, recipient, destination, origin, createdAt);
    }

    public Parcel(String id, String owner, String sender, String recipient, String destination,
                  String origin, LocalDateTime createdAt) {
        this.id = req(id, "id");
        this.owner = req(owner, "owner");
        this.sender = req(sender, "sender");
        this.recipient = req(recipient, "recipient");
        this.destination = req(destination, "destination");
        Objects.requireNonNull(createdAt, "createdAt");
        history.add(new StatusEvent(ParcelStatus.ORDER_PLACED, createdAt, origin, "Order created"));
    }

    private static String req(String v, String f) {
        if (v == null || v.isBlank()) throw new IllegalArgumentException(f + " must not be blank");
        return v.trim();
    }

    // ---- tracking state machine ----
    public StatusEvent advanceTo(ParcelStatus next, String location, String note, LocalDateTime when) {
        if (cancellation == CancellationState.CONFIRMED)
            throw new IllegalStateException("Parcel " + id + " is cancelled; tracking is locked");
        if (cancellation == CancellationState.REQUESTED)
            throw new IllegalStateException("A cancellation request is pending. Approve or reject it before updating tracking");
        ParcelStatus current = getStatus();
        if (!current.canTransitionTo(next)) throw new InvalidTransitionException(id, current, next);
        LocalDateTime last = history.get(history.size() - 1).timestamp();
        if (when.isBefore(last))
            throw new IllegalArgumentException("Timestamp " + when + " is earlier than last event " + last);
        StatusEvent ev = new StatusEvent(next, when, location, note);
        history.add(ev);
        return ev;
    }

    public StatusEvent advanceTo(ParcelStatus next, String location, String note) {
        return advanceTo(next, location, note, LocalDateTime.now(Clock.systemDefaultZone()));
    }

    // ---- cancellation workflow: NONE/REJECTED -> REQUESTED -> CONFIRMED | REJECTED ----
    public boolean canRequestCancellation() {
        return (cancellation == CancellationState.NONE || cancellation == CancellationState.REJECTED)
                && getStatus().ordinal() < ParcelStatus.OUT_FOR_DELIVERY.ordinal();
    }

    public void requestCancellation(String reason, String actor, LocalDateTime when) {
        if (!canRequestCancellation()) throw new IllegalStateException(switch (cancellation) {
            case CONFIRMED -> "This parcel is already cancelled";
            case REQUESTED -> "A cancellation request is already awaiting admin review";
            default -> "A parcel can't be cancelled once it is out for delivery or delivered";
        });
        if (reason == null || reason.isBlank()) throw new IllegalArgumentException("Please give a reason for cancelling");
        cancellation = CancellationState.REQUESTED;
        cancelReason = reason.trim();
        decisionNote = "";
        cancelRequestedAt = when;
        activity.add(new ActivityEvent(when, actor, "Cancellation requested: " + cancelReason));
    }

    public void confirmCancellation(String admin, String note, LocalDateTime when) {
        decide(CancellationState.CONFIRMED, "Cancellation approved", admin, note, when);
    }

    public void rejectCancellation(String admin, String note, LocalDateTime when) {
        decide(CancellationState.REJECTED, "Cancellation declined", admin, note, when);
    }

    private void decide(CancellationState to, String text, String admin, String note, LocalDateTime when) {
        if (cancellation != CancellationState.REQUESTED)
            throw new IllegalStateException("There is no pending cancellation request for " + id);
        cancellation = to;
        decisionNote = note == null ? "" : note.trim();
        activity.add(new ActivityEvent(when, admin, text + (decisionNote.isEmpty() ? "" : ": " + decisionNote)));
    }

    // ---- read-only accessors ----
    public ParcelStatus getStatus() { return history.get(history.size() - 1).status(); }
    public boolean isDelivered() { return getStatus() == ParcelStatus.DELIVERED; }
    public boolean isCancelled() { return cancellation == CancellationState.CONFIRMED; }
    public List<StatusEvent> getHistory() { return Collections.unmodifiableList(history); }
    public List<ActivityEvent> getActivity() { return Collections.unmodifiableList(activity); }
    public CancellationState getCancellation() { return cancellation; }
    public String getCancelReason() { return cancelReason; }
    public String getDecisionNote() { return decisionNote; }
    public LocalDateTime getCancelRequestedAt() { return cancelRequestedAt; }
    public String getId() { return id; }
    public String getOwner() { return owner; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getDestination() { return destination; }

    @Override public boolean equals(Object o) { return o instanceof Parcel p && p.id.equals(id); }
    @Override public int hashCode() { return id.hashCode(); }
    @Override public String toString() {
        return String.format("%s  %s -> %s (%s)  [%s%s]", id, sender, recipient, destination,
                getStatus().label(), isCancelled() ? ", CANCELLED" : "");
    }
}
