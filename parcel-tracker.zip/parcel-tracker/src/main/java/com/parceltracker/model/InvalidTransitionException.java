package com.parceltracker.model;

/** Thrown when a status change violates the state machine rules. */
public class InvalidTransitionException extends RuntimeException {
    private final ParcelStatus from;
    private final ParcelStatus to;

    public InvalidTransitionException(String parcelId, ParcelStatus from, ParcelStatus to) {
        super("Parcel " + parcelId + ": illegal transition " + from + " -> " + to
                + (from.isTerminal() ? " (parcel is already final)"
                                     : " (allowed: " + from.allowedNext() + ")"));
        this.from = from;
        this.to = to;
    }

    public ParcelStatus getFrom() { return from; }
    public ParcelStatus getTo()   { return to; }
}
