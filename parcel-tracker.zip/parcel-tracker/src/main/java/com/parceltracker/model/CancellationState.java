package com.parceltracker.model;

public enum CancellationState { NONE, REQUESTED, CONFIRMED, REJECTED }
