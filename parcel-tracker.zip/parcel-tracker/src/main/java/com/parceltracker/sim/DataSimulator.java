package com.parceltracker.sim;

import com.parceltracker.model.*;
import com.parceltracker.service.ParcelService;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

/** Seeded, reproducible demo data: parcels at random stages, some with cancellation requests. */
public class DataSimulator {
    /** {username, display name} of the demo customers. */
    public static final String[][] USERS = {{"aarav", "Aarav Sharma"}, {"priya", "Priya Nair"},
            {"karthik", "Karthik Raj"}, {"meera", "Meera Iyer"}};
    private static final List<String> RECIPIENTS = List.of("Rohan Gupta", "Ananya Das", "Vikram Singh",
            "Sneha Reddy", "Arjun Menon", "Divya Pillai", "Imran Khan", "Lakshmi Rao");
    private static final List<String> CITIES = List.of("Chennai", "Bengaluru", "Mumbai", "Delhi",
            "Hyderabad", "Kolkata", "Pune", "Kochi", "Coimbatore", "Jaipur");
    private static final List<String> REASONS = List.of("Ordered by mistake", "Wrong delivery address",
            "Found a better price elsewhere", "No longer needed", "Delivery taking too long");

    public static int populate(ParcelService service, int count, long seed) {
        Random r = new Random(seed);
        LocalDateTime base = LocalDateTime.of(2024, 1, 1, 9, 0);
        for (int i = 0; i < count; i++) {
            String[] owner = USERS[r.nextInt(USERS.length)];
            String origin = CITIES.get(r.nextInt(CITIES.size()));
            String dest = CITIES.get(r.nextInt(CITIES.size()));
            LocalDateTime t = base.plusHours(r.nextInt(24 * 60));
            Parcel p = service.createFor(owner[0], owner[1], RECIPIENTS.get(r.nextInt(RECIPIENTS.size())), dest, origin, t);
            int steps = r.nextInt(ParcelStatus.values().length);
            for (int s = 0; s < steps; s++) {
                t = t.plusHours(4 + r.nextInt(20));
                ParcelStatus next = p.getStatus().next();
                p.advanceTo(next, (next == ParcelStatus.PICKED_UP || next == ParcelStatus.IN_TRANSIT ? origin : dest) + " Hub",
                        "Auto-simulated", t);
            }
            if (p.canRequestCancellation() && r.nextInt(100) < 15) {
                p.requestCancellation(REASONS.get(r.nextInt(REASONS.size())), owner[0], t.plusHours(1));
                int d = r.nextInt(10);
                if (d < 3) p.confirmCancellation("admin", "Approved as requested", t.plusHours(3));
                else if (d < 5) p.rejectCancellation("admin", "Parcel already dispatched", t.plusHours(3));
            }
        }
        return count;
    }
}
