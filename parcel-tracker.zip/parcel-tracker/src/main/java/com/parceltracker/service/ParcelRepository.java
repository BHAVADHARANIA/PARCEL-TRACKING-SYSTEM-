package com.parceltracker.service;

import com.parceltracker.model.Parcel;
import java.util.*;

/** Simple in-memory store (insertion-ordered). */
public class ParcelRepository {
    private final Map<String, Parcel> store = new LinkedHashMap<>();

    public void save(Parcel p) {
        if (store.putIfAbsent(p.getId(), p) != null)
            throw new IllegalArgumentException("Duplicate parcel id: " + p.getId());
    }
    public Optional<Parcel> findById(String id) { return Optional.ofNullable(id == null ? null : store.get(id.trim().toUpperCase())); }
    public List<Parcel> findAll() { return List.copyOf(store.values()); }
    public int count() { return store.size(); }
}
