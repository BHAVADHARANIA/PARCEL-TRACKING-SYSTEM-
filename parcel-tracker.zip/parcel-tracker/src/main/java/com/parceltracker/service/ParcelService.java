package com.parceltracker.service;

import com.parceltracker.model.*;
import java.time.LocalDateTime;
import java.util.*;

public class ParcelService {
    private final ParcelRepository repo;
    private int seq = 1000;

    public ParcelService(ParcelRepository repo) { this.repo = repo; }

    public Parcel createParcel(String sender, String recipient, String destination, String origin) {
        return createFor(sender, sender, recipient, destination, origin, LocalDateTime.now());
    }

    public Parcel createParcel(String sender, String recipient, String destination, String origin, LocalDateTime at) {
        return createFor(sender, sender, recipient, destination, origin, at);
    }

    public Parcel createFor(String owner, String senderName, String recipient, String destination,
                            String origin, LocalDateTime at) {
        Parcel p = new Parcel("PKG" + (++seq), owner, senderName, recipient, destination, origin, at);
        repo.save(p);
        return p;
    }

    public Parcel get(String id) {
        return repo.findById(id).orElseThrow(() -> new NoSuchElementException("No parcel with id " + id));
    }

    public StatusEvent update(String id, ParcelStatus next, String location, String note) {
        return get(id).advanceTo(next, location, note);
    }

    public StatusEvent advanceToNext(String id, String location, String note) {
        Parcel p = get(id);
        ParcelStatus next = p.getStatus().next();
        if (next == null) throw new InvalidTransitionException(p.getId(), p.getStatus(), p.getStatus());
        return p.advanceTo(next, location, note);
    }

    /** Customer action: only the owner may request. */
    public void requestCancel(String id, String username, String reason) {
        Parcel p = get(id);
        if (!p.getOwner().equals(username)) throw new SecurityException("You can only cancel your own parcels");
        p.requestCancellation(reason, username, LocalDateTime.now());
    }

    /** Admin actions. */
    public void confirmCancel(String id, String admin, String note) { get(id).confirmCancellation(admin, note, LocalDateTime.now()); }
    public void rejectCancel(String id, String admin, String note) { get(id).rejectCancellation(admin, note, LocalDateTime.now()); }

    public List<Parcel> all() { return repo.findAll(); }

    public Map<ParcelStatus, Long> summary() {
        Map<ParcelStatus, Long> m = new EnumMap<>(ParcelStatus.class);
        for (ParcelStatus s : ParcelStatus.values()) m.put(s, 0L);
        for (Parcel p : repo.findAll()) m.merge(p.getStatus(), 1L, Long::sum);
        return m;
    }
}
