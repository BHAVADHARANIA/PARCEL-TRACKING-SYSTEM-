package com.parceltracker.web;

import com.parceltracker.auth.AuthService;
import com.parceltracker.auth.AuthService.Role;
import com.parceltracker.auth.AuthService.User;
import com.parceltracker.model.*;
import com.parceltracker.service.*;
import com.parceltracker.sim.DataSimulator;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/** Browser front end: JSON API (session-cookie auth, role-based access) + ./web/index.html. */
public class WebApp {
    private static final int PORT = 8080;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private final ParcelService svc;
    private final AuthService auth;

    WebApp(ParcelService svc, AuthService auth) { this.svc = svc; this.auth = auth; }

    public static void main(String[] args) throws Exception {
        ParcelService svc = new ParcelService(new ParcelRepository());
        DataSimulator.populate(svc, 120, 42L);
        AuthService auth = new AuthService();
        auth.register("admin", "Operations Admin", "Admin@123", Role.ADMIN);
        for (String[] u : DataSimulator.USERS) auth.register(u[0], u[1], "User@123", Role.USER);

        WebApp app = new WebApp(svc, auth);
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", PORT), 0);
        server.createContext("/", app::handle);
        server.start();
        String url = "http://localhost:" + PORT;
        System.out.println("ParcelTrack running at " + url + "  (close this window to stop)");
        try {
            if (java.awt.Desktop.isDesktopSupported()) java.awt.Desktop.getDesktop().browse(URI.create(url));
        } catch (Throwable t) { System.out.println("Open " + url + " in your browser."); }
    }

    private void handle(HttpExchange ex) throws IOException {
        try {
            synchronized (svc) { route(ex); }
        } catch (SecurityException e) { send(ex, 403, err(e.getMessage()));
        } catch (NoSuchElementException e) { send(ex, 404, err(e.getMessage()));
        } catch (InvalidTransitionException | IllegalStateException e) { send(ex, 409, err(e.getMessage()));
        } catch (IllegalArgumentException e) { send(ex, 400, err(e.getMessage()));
        } catch (Exception e) { send(ex, 500, err("Server error: " + e)); }
    }

    private void route(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath(), m = ex.getRequestMethod();

        if (path.equals("/") || path.equals("/index.html")) {
            Path page = Path.of("web", "index.html");
            if (!Files.exists(page)) { send(ex, 404, err("web/index.html not found. Start from the project folder.")); return; }
            ex.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            sendRaw(ex, 200, Files.readString(page));
            return;
        }
        if (path.equals("/api/login") && m.equals("POST")) { login(ex); return; }
        if (path.equals("/api/logout") && m.equals("POST")) {
            auth.logout(token(ex));
            ex.getResponseHeaders().add("Set-Cookie", "SESSION=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0");
            send(ex, 200, "{}");
            return;
        }

        User u = auth.userFor(token(ex)).orElse(null);
        if (u == null) { send(ex, 401, err("Please sign in to continue")); return; }
        boolean admin = u.role() == Role.ADMIN;

        if (path.equals("/api/me")) { send(ex, 200, userJson(u)); return; }

        if (path.equals("/api/parcels")) {
            if (m.equals("GET")) {
                send(ex, 200, svc.all().stream().filter(p -> admin || p.getOwner().equals(u.username()))
                        .map(p -> parcelJson(p, false)).collect(Collectors.joining(",", "[", "]")));
                return;
            }
            if (m.equals("POST")) {
                if (admin) throw new SecurityException("Administrators don't create shipments");
                Map<String, String> f = form(ex);
                Parcel p = svc.createFor(u.username(), u.name(), f.get("recipient"), f.get("destination"),
                        f.get("origin"), LocalDateTime.now());
                send(ex, 201, parcelJson(p, true));
                return;
            }
        }

        if (path.startsWith("/api/parcels/")) {
            String[] parts = path.substring("/api/parcels/".length()).split("/");
            String id = parts[0].toUpperCase();
            Parcel p = svc.get(id);
            if (!admin && !p.getOwner().equals(u.username()))
                throw new SecurityException("You don't have access to this parcel");

            if (parts.length == 1 && m.equals("GET")) { send(ex, 200, parcelJson(p, true)); return; }

            if (parts.length >= 2 && m.equals("POST")) {
                Map<String, String> f = form(ex);
                switch (parts[1]) {
                    case "advance" -> { requireAdmin(admin); svc.advanceToNext(id, f.get("location"), f.get("note")); }
                    case "status" -> { requireAdmin(admin);
                        svc.update(id, ParcelStatus.valueOf(String.valueOf(f.get("status"))), f.get("location"), f.get("note")); }
                    case "cancel" -> {
                        if (parts.length == 2) {
                            if (admin) throw new SecurityException("Only the parcel owner can request a cancellation");
                            svc.requestCancel(id, u.username(), f.get("reason"));
                        } else if (parts[2].equals("confirm")) { requireAdmin(admin); svc.confirmCancel(id, u.username(), f.get("note")); }
                        else if (parts[2].equals("reject")) { requireAdmin(admin); svc.rejectCancel(id, u.username(), f.get("note")); }
                        else { send(ex, 404, err("Unknown action")); return; }
                    }
                    default -> { send(ex, 404, err("Unknown action")); return; }
                }
                send(ex, 200, parcelJson(svc.get(id), true));
                return;
            }
        }
        send(ex, 404, err("Not found: " + path));
    }

    private void login(HttpExchange ex) throws IOException {
        Map<String, String> f = form(ex);
        Optional<User> ou = auth.authenticate(f.get("username"), f.get("password"));
        if (ou.isEmpty()) { send(ex, 401, err("Invalid username or password")); return; }
        User u = ou.get();
        String want = f.getOrDefault("role", "USER");
        if (!u.role().name().equals(want)) {
            send(ex, 403, err(u.role() == Role.ADMIN ? "Administrator accounts must sign in from the Administrator tab"
                                                    : "This account does not have administrator access"));
            return;
        }
        ex.getResponseHeaders().add("Set-Cookie", "SESSION=" + auth.login(u) + "; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800");
        send(ex, 200, userJson(u));
    }

    private static void requireAdmin(boolean admin) { if (!admin) throw new SecurityException("Administrator access required"); }

    private static String token(HttpExchange ex) {
        String c = ex.getRequestHeaders().getFirst("Cookie");
        if (c == null) return null;
        for (String part : c.split(";")) { part = part.trim(); if (part.startsWith("SESSION=")) return part.substring(8); }
        return null;
    }

    private static String userJson(User u) {
        return "{\"username\":" + q(u.username()) + ",\"name\":" + q(u.name()) + ",\"role\":" + q(u.role().name()) + "}";
    }

    private static String parcelJson(Parcel p, boolean detail) {
        ParcelStatus s = p.getStatus();
        List<StatusEvent> h = p.getHistory();
        StringBuilder sb = new StringBuilder("{")
            .append("\"id\":").append(q(p.getId()))
            .append(",\"owner\":").append(q(p.getOwner()))
            .append(",\"sender\":").append(q(p.getSender()))
            .append(",\"recipient\":").append(q(p.getRecipient()))
            .append(",\"destination\":").append(q(p.getDestination()))
            .append(",\"status\":").append(q(s.name()))
            .append(",\"label\":").append(q(s.label()))
            .append(",\"index\":").append(s.ordinal())
            .append(",\"terminal\":").append(s.isTerminal())
            .append(",\"updatedAt\":").append(q(h.get(h.size() - 1).timestamp().format(FMT)))
            .append(",\"cancellation\":").append(q(p.getCancellation().name()))
            .append(",\"canCancel\":").append(p.canRequestCancellation())
            .append(",\"cancelReason\":").append(q(p.getCancelReason()))
            .append(",\"decisionNote\":").append(q(p.getDecisionNote()))
            .append(",\"cancelRequestedAt\":").append(q(p.getCancelRequestedAt() == null ? "" : p.getCancelRequestedAt().format(FMT)));
        if (detail) {
            sb.append(",\"history\":").append(h.stream().map(e ->
                "{\"label\":" + q(e.status().label()) + ",\"timestamp\":" + q(e.timestamp().format(FMT)) +
                ",\"location\":" + q(e.location()) + ",\"note\":" + q(e.note()) + "}")
                .collect(Collectors.joining(",", "[", "]")));
            sb.append(",\"activity\":").append(p.getActivity().stream().map(a ->
                "{\"timestamp\":" + q(a.timestamp().format(FMT)) + ",\"actor\":" + q(a.actor()) + ",\"text\":" + q(a.text()) + "}")
                .collect(Collectors.joining(",", "[", "]")));
        }
        return sb.append("}").toString();
    }

    private static Map<String, String> form(HttpExchange ex) throws IOException {
        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> m = new HashMap<>();
        for (String pair : body.split("&")) {
            if (pair.isEmpty()) continue;
            int i = pair.indexOf('=');
            m.put(URLDecoder.decode(i < 0 ? pair : pair.substring(0, i), StandardCharsets.UTF_8),
                  i < 0 ? "" : URLDecoder.decode(pair.substring(i + 1), StandardCharsets.UTF_8));
        }
        return m;
    }

    private static String q(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> { if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c); }
            }
        }
        return sb.append('"').toString();
    }

    private static String err(String msg) { return "{\"error\":" + q(msg) + "}"; }

    private static void send(HttpExchange ex, int code, String json) throws IOException {
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        sendRaw(ex, code, json);
    }

    private static void sendRaw(HttpExchange ex, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        ex.sendResponseHeaders(code, b.length);
        try (var os = ex.getResponseBody()) { os.write(b); }
    }
}
