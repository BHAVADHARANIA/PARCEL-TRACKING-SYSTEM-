package com.parceltracker;

import com.parceltracker.model.*;
import com.parceltracker.service.*;
import com.parceltracker.sim.DataSimulator;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SimulationTest {
    @Test void processes120ParcelsWithValidHistories() {
        ParcelService svc = new ParcelService(new ParcelRepository());
        DataSimulator.populate(svc, 120, 42L);
        assertTrue(svc.all().size() >= 100);

        for (Parcel p : svc.all()) {
            List<StatusEvent> h = p.getHistory();
            assertEquals(ParcelStatus.ORDER_PLACED, h.get(0).status());
            for (int i = 1; i < h.size(); i++) {
                assertTrue(h.get(i - 1).status().canTransitionTo(h.get(i).status()));
                assertFalse(h.get(i).timestamp().isBefore(h.get(i - 1).timestamp()));
            }
        }
        long total = svc.summary().values().stream().mapToLong(Long::longValue).sum();
        assertEquals(svc.all().size(), total);
    }

    @Test void simulationIsReproducible() {
        ParcelService a = new ParcelService(new ParcelRepository());
        ParcelService b = new ParcelService(new ParcelRepository());
        DataSimulator.populate(a, 100, 7L); DataSimulator.populate(b, 100, 7L);
        assertEquals(a.summary(), b.summary());
    }

    @Test void serviceRejectsAdvancingDeliveredParcel() {
        ParcelService svc = new ParcelService(new ParcelRepository());
        Parcel p = svc.createParcel("A", "B", "Chennai", "Pune");
        for (int i = 0; i < 5; i++) svc.advanceToNext(p.getId(), "Hub", "");
        assertTrue(p.isDelivered());
        assertThrows(InvalidTransitionException.class, () -> svc.advanceToNext(p.getId(), "Hub", ""));
    }
}
