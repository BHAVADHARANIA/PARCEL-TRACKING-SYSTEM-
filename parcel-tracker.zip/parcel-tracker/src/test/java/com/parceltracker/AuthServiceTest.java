package com.parceltracker;

import com.parceltracker.auth.AuthService;
import com.parceltracker.auth.AuthService.Role;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AuthServiceTest {
    private AuthService auth() {
        AuthService a = new AuthService();
        a.register("admin", "Admin", "Admin@123", Role.ADMIN);
        a.register("aarav", "Aarav", "User@123", Role.USER);
        return a;
    }

    @Test void correctPasswordAuthenticatesWithRole() {
        assertEquals(Role.ADMIN, auth().authenticate("ADMIN ", "Admin@123").orElseThrow().role());
    }

    @Test void wrongPasswordOrUnknownUserRejected() {
        AuthService a = auth();
        assertTrue(a.authenticate("admin", "nope").isEmpty());
        assertTrue(a.authenticate("ghost", "User@123").isEmpty());
        assertTrue(a.authenticate(null, null).isEmpty());
    }

    @Test void sessionLifecycle() {
        AuthService a = auth();
        String token = a.login(a.authenticate("aarav", "User@123").orElseThrow());
        assertEquals("aarav", a.userFor(token).orElseThrow().username());
        a.logout(token);
        assertTrue(a.userFor(token).isEmpty());
    }
}
