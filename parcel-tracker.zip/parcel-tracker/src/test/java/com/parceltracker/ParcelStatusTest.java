package com.parceltracker;

import com.parceltracker.model.ParcelStatus;
import org.junit.jupiter.api.Test;
import static com.parceltracker.model.ParcelStatus.*;
import static org.junit.jupiter.api.Assertions.*;

class ParcelStatusTest {
    @Test void hasExactlySixStages() { assertEquals(6, ParcelStatus.values().length); }

    @Test void happyPathIsLinear() {
        ParcelStatus s = ORDER_PLACED; int hops = 0;
        while (!s.isTerminal()) { assertTrue(s.canTransitionTo(s.next())); s = s.next(); hops++; }
        assertEquals(DELIVERED, s); assertEquals(5, hops);
    }

    @Test void skippingAndBackwardsAreIllegal() {
        assertFalse(ORDER_PLACED.canTransitionTo(IN_TRANSIT));
        assertFalse(PICKED_UP.canTransitionTo(DELIVERED));
        assertFalse(OUT_FOR_DELIVERY.canTransitionTo(IN_TRANSIT));
        assertFalse(IN_TRANSIT.canTransitionTo(IN_TRANSIT));
        assertFalse(IN_TRANSIT.canTransitionTo(null));
    }

    @Test void deliveredIsTerminal() {
        assertTrue(DELIVERED.isTerminal());
        assertNull(DELIVERED.next());
    }
}
