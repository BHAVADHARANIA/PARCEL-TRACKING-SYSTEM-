package com.parceltracker;

import com.parceltracker.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

class CancellationTest {
    private final LocalDateTime t0 = LocalDateTime.of(2024, 3, 1, 10, 0);
    private Parcel p;

    @BeforeEach void setUp() { p = new Parcel("PKG1", "aarav", "Aarav", "Ravi", "Chennai", "Pune", t0); }

    @Test void requestThenConfirmLocksTracking() {
        p.requestCancellation("Mistake", "aarav", t0.plusHours(1));
        assertEquals(CancellationState.REQUESTED, p.getCancellation());
        p.confirmCancellation("admin", "ok", t0.plusHours(2));
        assertTrue(p.isCancelled());
        assertThrows(IllegalStateException.class, () -> p.advanceTo(ParcelStatus.PICKED_UP, "Hub", "", t0.plusHours(3)));
        assertEquals(2, p.getActivity().size());
    }

    @Test void trackingBlockedWhilePending() {
        p.requestCancellation("Mistake", "aarav", t0.plusHours(1));
        assertThrows(IllegalStateException.class, () -> p.advanceTo(ParcelStatus.PICKED_UP, "Hub", "", t0.plusHours(2)));
    }

    @Test void rejectedRequestAllowsTrackingAndRetry() {
        p.requestCancellation("Mistake", "aarav", t0.plusHours(1));
        p.rejectCancellation("admin", "Dispatched", t0.plusHours(2));
        p.advanceTo(ParcelStatus.PICKED_UP, "Hub", "", t0.plusHours(3));
        assertTrue(p.canRequestCancellation());
    }

    @Test void cannotCancelOnceOutForDelivery() {
        LocalDateTime t = t0;
        while (p.getStatus() != ParcelStatus.OUT_FOR_DELIVERY) { t = t.plusHours(1); p.advanceTo(p.getStatus().next(), "Hub", "", t); }
        assertFalse(p.canRequestCancellation());
        assertThrows(IllegalStateException.class, () -> p.requestCancellation("late", "aarav", LocalDateTime.now()));
    }

    @Test void reasonRequiredAndDecisionNeedsPendingRequest() {
        assertThrows(IllegalArgumentException.class, () -> p.requestCancellation(" ", "aarav", t0.plusHours(1)));
        assertThrows(IllegalStateException.class, () -> p.confirmCancellation("admin", "", t0.plusHours(1)));
    }
}
