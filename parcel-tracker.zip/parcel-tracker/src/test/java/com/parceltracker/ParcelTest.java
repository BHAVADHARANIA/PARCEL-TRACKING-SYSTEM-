package com.parceltracker;

import com.parceltracker.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

class ParcelTest {
    private final LocalDateTime t0 = LocalDateTime.of(2024, 3, 1, 10, 0);
    private Parcel p;

    @BeforeEach void setUp() { p = new Parcel("PKG1", "Asha", "Ravi", "Chennai", "Pune", t0); }

    @Test void startsAtOrderPlacedWithOneEvent() {
        assertEquals(ParcelStatus.ORDER_PLACED, p.getStatus());
        assertEquals(1, p.getHistory().size());
    }

    @Test void validTransitionAppendsHistory() {
        p.advanceTo(ParcelStatus.PICKED_UP, "Pune Hub", "ok", t0.plusHours(2));
        assertEquals(ParcelStatus.PICKED_UP, p.getStatus());
        assertEquals(2, p.getHistory().size());
    }

    @Test void invalidTransitionThrowsAndLeavesStateUnchanged() {
        InvalidTransitionException ex = assertThrows(InvalidTransitionException.class,
                () -> p.advanceTo(ParcelStatus.DELIVERED, "x", "", t0.plusHours(1)));
        assertEquals(ParcelStatus.ORDER_PLACED, ex.getFrom());
        assertEquals(ParcelStatus.ORDER_PLACED, p.getStatus());
        assertEquals(1, p.getHistory().size());
    }

    @Test void cannotChangeAfterDelivered() {
        LocalDateTime t = t0;
        while (!p.isDelivered()) { t = t.plusHours(1); p.advanceTo(p.getStatus().next(), "Hub", "", t); }
        assertThrows(InvalidTransitionException.class,
                () -> p.advanceTo(ParcelStatus.PICKED_UP, "Hub", "", LocalDateTime.of(2030,1,1,0,0)));
    }

    @Test void historyIsReadOnly() {
        assertThrows(UnsupportedOperationException.class, () -> p.getHistory().clear());
        assertThrows(UnsupportedOperationException.class,
                () -> p.getHistory().add(new StatusEvent(ParcelStatus.DELIVERED, t0, "x", "")));
    }

    @Test void earlierTimestampRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> p.advanceTo(ParcelStatus.PICKED_UP, "Hub", "", t0.minusHours(1)));
    }

    @Test void blankFieldsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new Parcel(" ", "a", "b", "c", "d", t0));
    }
}
